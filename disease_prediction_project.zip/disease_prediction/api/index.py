import os
import sys
import json
import urllib.parse
from http.server import BaseHTTPRequestHandler
import pandas as pd
import numpy as np

# In Vercel serverless environment:
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

try:
    from src.health_guidance import build_full_health_assessment
    from src.report_generator import build_pdf_health_report
except Exception as e:
    print(f"Health guidance import warning: {e}")
    build_full_health_assessment = None
    build_pdf_health_report = None

MODELS_DIR = os.path.join(BASE_DIR, "models")

LOADED_BUNDLES = {}

def get_model_bundle(dataset_key):
    global LOADED_BUNDLES
    if dataset_key in LOADED_BUNDLES:
        return LOADED_BUNDLES[dataset_key]
    
    try:
        import joblib
        bundle_path = os.path.join(MODELS_DIR, f"{dataset_key}_bundle.joblib")
        if os.path.exists(bundle_path):
            bundle = joblib.load(bundle_path)
            LOADED_BUNDLES[dataset_key] = bundle
            return bundle
    except Exception as e:
        print(f"Bundle load exception: {e}")
    return None

def compute_risk(dataset_key, features):
    # Try using trained pipeline bundle first
    bundle = get_model_bundle(dataset_key)
    if bundle and "models" in bundle:
        try:
            df = pd.DataFrame([features])
            all_preds = {}
            for name, model in bundle["models"].items():
                if hasattr(model, "predict_proba"):
                    p = float(model.predict_proba(df)[0, 1])
                else:
                    d = float(model.decision_function(df)[0])
                    p = 1 / (1 + np.exp(-d))
                all_preds[name] = round(p, 4)
            prob = all_preds.get("Soft Voting Ensemble", 0.5)
            return prob, all_preds
        except Exception as e:
            print(f"Inference error: {e}")

    # Fallback algorithmic inference
    p = 0.15
    if dataset_key == "heart":
        score = 0
        if float(features.get("chol", 0)) > 240: score += 2
        if float(features.get("trestbps", 0)) > 140: score += 2
        if int(features.get("cp", 0)) == 4: score += 2
        if int(features.get("exang", 0)) == 1: score += 2
        if float(features.get("oldpeak", 0)) > 1.5: score += 2
        if int(features.get("ca", 0)) > 0: score += int(features.get("ca", 0)) * 1.5
        if int(features.get("thal", 0)) == 7: score += 2
        p = min(0.98, max(0.08, score / 12))
    elif dataset_key == "diabetes":
        score = 0
        if float(features.get("Glucose", 0)) > 140: score += 4
        if float(features.get("BMI", 0)) > 30: score += 2
        if float(features.get("Age", 0)) > 45: score += 2
        p = min(0.95, max(0.10, score / 9))
    else:
        radius = float(features.get("mean_radius", 14.0))
        p = min(0.99, max(0.02, (radius - 10) / 10))

    all_preds = {
        "Logistic Regression": round(p, 4),
        "Decision Tree": round(0.9 if p >= 0.5 else 0.1, 4),
        "Random Forest": round(p, 4),
        "Gradient Boosting": round(p, 4),
        "Soft Voting Ensemble": round(p, 4),
        "Stacking Ensemble": round(p, 4)
    }
    return p, all_preds

class handler(BaseHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        clean_path = self.path.split("?")[0]
        if clean_path in ["/api", "/api/", "/api/status", "/api/health"]:
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"status": "online", "system": "Smart Disease Prediction API"}).encode("utf-8"))
            return

        # Serve static file fallback
        target = "index.html" if clean_path in ["/", "/index.html"] else clean_path.lstrip("/")
        
        candidate_paths = [
            os.path.join(BASE_DIR, "public", target),
            os.path.join(BASE_DIR, target),
            os.path.join(BASE_DIR, "static", target)
        ]
        
        found_file = None
        for p in candidate_paths:
            if os.path.exists(p) and os.path.isfile(p):
                found_file = p
                break
                
        if found_file:
            content_type = "text/html; charset=utf-8"
            if found_file.endswith(".css"):
                content_type = "text/css"
            elif found_file.endswith(".js"):
                content_type = "application/javascript"
            elif found_file.endswith(".json"):
                content_type = "application/json"

            try:
                with open(found_file, "rb") as f:
                    content = f.read()

                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return
            except Exception as e:
                print(f"Error reading {found_file}: {e}")

        # Default fallback
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({"status": "online", "system": "Smart Disease Prediction API"}).encode("utf-8"))

    def do_POST(self):
        clean_path = self.path.split("?")[0]
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
        try:
            data = json.loads(body)
        except Exception:
            data = {}

        if clean_path in ["/api/download_pdf", "/download_pdf", "/api/generate_report_pdf"]:
            dataset_key = data.get("dataset", "heart")
            raw_features = data.get("features", {})
            full_report = data.get("health_assessment")
            all_preds = data.get("all_models_probabilities", {})

            if not full_report and build_full_health_assessment:
                prob = float(data.get("probability", 0.5))
                threshold = float(data.get("threshold", 0.5))
                full_report = build_full_health_assessment(dataset_key, prob, threshold, raw_features)

            if full_report and all_preds:
                full_report["all_models_probabilities"] = all_preds

            if build_pdf_health_report and full_report:
                try:
                    pdf_bytes = build_pdf_health_report(full_report, raw_features)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/pdf")
                    self.send_header("Content-Disposition", f'attachment; filename="Health_Assessment_Report_{dataset_key}.pdf"')
                    self.send_header("Content-Length", str(len(pdf_bytes)))
                    self.end_headers()
                    self.wfile.write(pdf_bytes)
                    return
                except Exception as e:
                    print(f"PDF serverless build error: {e}")

            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "PDF generation failed"}).encode("utf-8"))
            return

        dataset_key = data.get("dataset", "heart")
        features = data.get("features", {})
        threshold = float(data.get("threshold", 0.5))

        prob, all_preds = compute_risk(dataset_key, features)
        pct = round(prob * 100, 1)
        is_high = prob >= threshold

        if build_full_health_assessment:
            full_report = build_full_health_assessment(dataset_key, prob, threshold, features)
            full_report["all_models_probabilities"] = all_preds
            response = {
                "dataset": dataset_key,
                "probability": round(prob, 4),
                "probability_pct": pct,
                "prediction": 1 if is_high else 0,
                "diagnosis": "High Risk Detected" if is_high else "Low Risk / Safe",
                "all_models_probabilities": all_preds,
                "humanized_assessment": {
                    "category": full_report["category"],
                    "badge": full_report["badge"],
                    "headline": full_report["headline"],
                    "drivers": full_report["contributing_factors"],
                    "recommendations": full_report["doctor_consultation"]["action_plan"],
                    "urgency": full_report["doctor_consultation"]["urgency"]
                },
                "health_assessment": full_report
            }
        else:
            response = {
                "dataset": dataset_key,
                "probability": round(prob, 4),
                "probability_pct": pct,
                "prediction": 1 if is_high else 0,
                "diagnosis": "High Risk Detected" if is_high else "Low Risk / Safe",
                "all_models_probabilities": all_preds,
                "humanized_assessment": {
                    "category": "High Disease Risk Detected" if is_high else "Low Disease Risk (Favorable Profile)",
                    "headline": f"Assessment indicates {pct}% estimated disease risk likelihood.",
                    "badge": "danger" if is_high else "success",
                    "drivers": ["Parameters evaluated."],
                    "recommendations": ["Consult doctor."],
                    "urgency": "Consultation Recommended" if is_high else "Routine Wellness"
                }
            }

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(response).encode("utf-8"))
