/**
 * Smart Disease Prediction System - Clean Light Theme Client Logic
 * Handles visible form inputs, 1-click test presets, live multi-model prediction,
 * personalized health recommendations, and PDF health report generation.
 */

let activeDisease = "heart";
let latestResultData = null;
let latestFeatures = null;

const SAMPLES = {
  heart: {
    healthy: {
      age: 42, sex: "0", trestbps: 118, chol: 185, fbs: "0",
      cp: "2", thalach: 172, exang: "0", restecg: "0",
      oldpeak: 0.1, slope: "1", ca: "0", thal: "3"
    },
    borderline: {
      age: 55, sex: "1", trestbps: 138, chol: 242, fbs: "0",
      cp: "3", thalach: 144, exang: "0", restecg: "1",
      oldpeak: 1.4, slope: "2", ca: "1", thal: "3"
    },
    highrisk: {
      age: 63, sex: "1", trestbps: 165, chol: 290, fbs: "1",
      cp: "4", thalach: 115, exang: "1", restecg: "2",
      oldpeak: 2.8, slope: "2", ca: "2", thal: "7"
    }
  },
  diabetes: {
    healthy: {
      diab_age: 26, diab_pregnancies: 1, diab_glucose: 92,
      diab_bp: 68, diab_bmi: 22.4, diab_insulin: 70, diab_dpf: 0.25
    },
    borderline: {
      diab_age: 42, diab_pregnancies: 3, diab_glucose: 128,
      diab_bp: 76, diab_bmi: 29.5, diab_insulin: 125, diab_dpf: 0.48
    },
    highrisk: {
      diab_age: 56, diab_pregnancies: 6, diab_glucose: 172,
      diab_bp: 88, diab_bmi: 37.8, diab_insulin: 220, diab_dpf: 0.95
    }
  },
  breast_cancer: {
    healthy: {
      bc_radius: 12.0, bc_texture: 14.5, bc_perimeter: 78.0,
      bc_area: 440, bc_smoothness: 0.08, bc_concavity: 0.02
    },
    borderline: {
      bc_radius: 14.8, bc_texture: 18.5, bc_perimeter: 96.0,
      bc_area: 680, bc_smoothness: 0.10, bc_concavity: 0.08
    },
    highrisk: {
      bc_radius: 20.5, bc_texture: 25.4, bc_perimeter: 138.0,
      bc_area: 1320, bc_smoothness: 0.12, bc_concavity: 0.25
    }
  }
};

document.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  const diseaseParam = urlParams.get('disease');
  const sampleParam = urlParams.get('sample');
  if (diseaseParam) {
    switchDisease(diseaseParam, true);
  }
  fillSample(sampleParam || "healthy");
});

function switchDisease(disease, skipFill = false) {
  activeDisease = disease;

  // Update header buttons
  document.getElementById("btn-switch-heart").classList.toggle("active", disease === "heart");
  document.getElementById("btn-switch-diabetes").classList.toggle("active", disease === "diabetes");
  document.getElementById("btn-switch-cancer").classList.toggle("active", disease === "breast_cancer");

  // Show selected form
  document.getElementById("form-heart").classList.toggle("active", disease === "heart");
  document.getElementById("form-diabetes").classList.toggle("active", disease === "diabetes");
  document.getElementById("form-cancer").classList.toggle("active", disease === "breast_cancer");

  const heading = document.getElementById("form-heading");
  const subheading = document.getElementById("form-subheading");

  if (disease === "heart") {
    heading.textContent = "📝 Enter Heart & Cardiovascular Test Numbers";
    subheading.textContent = "Fill in the patient's heart checkup numbers below, then click the blue button.";
  } else if (disease === "diabetes") {
    heading.textContent = "📝 Enter Diabetes & Metabolic Test Numbers";
    subheading.textContent = "Fill in the glucose, insulin, and BMI numbers below, then click the blue button.";
  } else {
    heading.textContent = "📝 Enter Breast Cell Biopsy Measurements";
    subheading.textContent = "Fill in the nuclear morphometry measurements below, then click the blue button.";
  }

  // Fill healthy sample as default unless skipped
  if (!skipFill) {
    fillSample("healthy");
  }
}

function fillSample(level) {
  const currentSet = SAMPLES[activeDisease] && SAMPLES[activeDisease][level];
  if (!currentSet) return;

  // Set values in all visible HTML input boxes
  Object.keys(currentSet).forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.value = currentSet[id];
      // Subtle highlight flash to show the box updated
      el.style.backgroundColor = "#e0f2fe";
      setTimeout(() => { el.style.backgroundColor = "#ffffff"; }, 350);
    }
  });

  // Automatically submit to see prediction instantly!
  performPrediction();
}

function handleFormSubmit(e) {
  if (e) e.preventDefault();
  performPrediction();
}

async function performPrediction() {
  const btn = document.getElementById("btn-predict");
  btn.disabled = true;
  btn.querySelector(".btn-text").textContent = "ANALYZING TEST NUMBERS...";

  let features = {};
  if (activeDisease === "heart") {
    features = {
      age: parseFloat(document.getElementById("age").value || 54),
      sex: parseInt(document.getElementById("sex").value || 1),
      cp: parseInt(document.getElementById("cp").value || 3),
      trestbps: parseFloat(document.getElementById("trestbps").value || 130),
      chol: parseFloat(document.getElementById("chol").value || 240),
      fbs: parseInt(document.getElementById("fbs").value || 0),
      restecg: parseInt(document.getElementById("restecg").value || 0),
      thalach: parseFloat(document.getElementById("thalach").value || 150),
      exang: parseInt(document.getElementById("exang").value || 0),
      oldpeak: parseFloat(document.getElementById("oldpeak").value || 1.0),
      slope: parseInt(document.getElementById("slope").value || 1),
      ca: parseInt(document.getElementById("ca").value || 0),
      thal: parseInt(document.getElementById("thal").value || 3)
    };
  } else if (activeDisease === "diabetes") {
    features = {
      Age: parseFloat(document.getElementById("diab_age").value || 33),
      Pregnancies: parseFloat(document.getElementById("diab_pregnancies").value || 3),
      Glucose: parseFloat(document.getElementById("diab_glucose").value || 120),
      BloodPressure: parseFloat(document.getElementById("diab_bp").value || 72),
      BMI: parseFloat(document.getElementById("diab_bmi").value || 32.0),
      Insulin: parseFloat(document.getElementById("diab_insulin").value || 80),
      DiabetesPedigreeFunction: parseFloat(document.getElementById("diab_dpf").value || 0.47),
      SkinThickness: 23.0
    };
  } else {
    // Breast cancer
    features = {
      mean_radius: parseFloat(document.getElementById("bc_radius").value || 14.1),
      mean_texture: parseFloat(document.getElementById("bc_texture").value || 19.2),
      mean_perimeter: parseFloat(document.getElementById("bc_perimeter").value || 92.0),
      mean_area: parseFloat(document.getElementById("bc_area").value || 654),
      mean_smoothness: parseFloat(document.getElementById("bc_smoothness").value || 0.09),
      mean_concavity: parseFloat(document.getElementById("bc_concavity").value || 0.08),
      mean_compactness: 0.10,
      mean_concave_points: 0.05,
      mean_symmetry: 0.18,
      mean_fractal_dimension: 0.06
    };
  }

  latestFeatures = features;

  const payload = {
    dataset: activeDisease,
    model: "Soft Voting Ensemble",
    threshold: 0.5,
    features: features
  };

  try {
    const res = await fetch("/api/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    renderResult(data);
  } catch (err) {
    console.warn("API request failed, using local fallback:", err);
    // Safe local calculation fallback
    const fallbackResult = calculateLocalFallback(activeDisease, features);
    renderResult(fallbackResult);
  } finally {
    btn.disabled = false;
    btn.querySelector(".btn-text").textContent = "CHECK DISEASE RISK NOW";
  }
}

function renderResult(data) {
  latestResultData = data;
  const prob = data.probability;
  const pct = data.probability_pct;
  const assessment = data.humanized_assessment || {};
  const health = data.health_assessment || {};

  // DOM elements
  const scoreRing = document.getElementById("score-ring");
  const scoreNum = document.getElementById("score-number");
  const statusPill = document.getElementById("status-pill");
  const verdictBanner = document.getElementById("verdict-banner");
  const verdictIcon = document.getElementById("verdict-icon");
  const verdictTitle = document.getElementById("verdict-title");
  const verdictDesc = document.getElementById("verdict-desc");
  const findingsList = document.getElementById("findings-list");
  const modelVotesList = document.getElementById("model-votes-list");

  scoreNum.textContent = `${pct}%`;

  // Colors: Green (< 35%), Yellow (35-65%), Red (>= 65%)
  let themeColor = "var(--color-green)";
  let statusClass = "status-green";
  let icon = "🟢";

  if (pct >= 65) {
    themeColor = "var(--color-red)";
    statusClass = "status-red";
    icon = "🔴";
    scoreNum.style.color = "var(--color-red)";
    statusPill.textContent = "HIGH RISK ALERT";
  } else if (pct >= 35) {
    themeColor = "var(--color-yellow)";
    statusClass = "status-yellow";
    icon = "🟡";
    scoreNum.style.color = "var(--color-yellow)";
    statusPill.textContent = "MEDIUM RISK (CAUTION)";
  } else {
    themeColor = "var(--color-green)";
    statusClass = "status-green";
    icon = "🟢";
    scoreNum.style.color = "var(--color-green)";
    statusPill.textContent = "LOW RISK (SAFE)";
  }

  scoreRing.style.background = `conic-gradient(${themeColor} ${pct}%, #e2e8f0 ${pct}%)`;
  statusPill.className = `status-pill ${statusClass}`;

  verdictIcon.textContent = icon;
  verdictTitle.textContent = assessment.category || health.category || "Health Assessment";
  verdictDesc.textContent = assessment.headline || health.headline || `Assessment indicates ${pct}% estimated disease risk.`;

  // 1. Findings List (Contributing Factors)
  findingsList.innerHTML = "";
  const drivers = health.contributing_factors || assessment.drivers || [];
  if (drivers.length > 0) {
    drivers.forEach(d => {
      const li = document.createElement("li");
      li.textContent = d;
      findingsList.appendChild(li);
    });
  } else {
    const li = document.createElement("li");
    li.textContent = "All test values within expected physiological bounds.";
    findingsList.appendChild(li);
  }

  // 2. Food Recommendations Card
  const food = health.food_recommendations || {};
  const preferUl = document.getElementById("food-prefer-list");
  if (preferUl) {
    preferUl.innerHTML = "";
    (food.prefer || []).forEach(item => {
      const li = document.createElement("li");
      li.textContent = item;
      preferUl.appendChild(li);
    });
  }

  const limitUl = document.getElementById("food-limit-list");
  if (limitUl) {
    limitUl.innerHTML = "";
    (food.limit || []).forEach(item => {
      const li = document.createElement("li");
      li.textContent = item;
      limitUl.appendChild(li);
    });
  }

  const mealDiv = document.getElementById("meal-ideas-list");
  if (mealDiv) {
    mealDiv.innerHTML = "";
    (food.meal_ideas || []).forEach(meal => {
      const div = document.createElement("div");
      div.className = "meal-entry";
      div.textContent = meal;
      mealDiv.appendChild(div);
    });
  }

  const foodDiscEl = document.getElementById("food-disclaimer");
  if (foodDiscEl && food.disclaimer) {
    foodDiscEl.textContent = `* ${food.disclaimer}`;
  }

  // 3. Lifestyle Suggestions Card
  const life = health.lifestyle_suggestions || {};
  const actEl = document.getElementById("life-activity-text");
  if (actEl) actEl.textContent = life.activity || "Aim for regular moderate aerobic physical activity.";
  const slpEl = document.getElementById("life-sleep-text");
  if (slpEl) slpEl.textContent = life.sleep || "Ensure 7 to 9 hours of uninterrupted sleep nightly.";
  const strEl = document.getElementById("life-stress-text");
  if (strEl) strEl.textContent = life.stress || "Practice daily conscious stress regulation techniques.";
  const hydEl = document.getElementById("life-hydration-text");
  if (hydEl) hydEl.textContent = life.hydration || "Drink 2.0 to 2.5 liters of clean water daily.";
  const smkEl = document.getElementById("life-smoking-text");
  if (smkEl) smkEl.textContent = life.smoking_alcohol || "Strictly avoid tobacco and eliminate or minimize alcohol.";

  const habitsUl = document.getElementById("habits-list");
  if (habitsUl) {
    habitsUl.innerHTML = "";
    (life.habits_checklist || []).forEach(habit => {
      const li = document.createElement("li");
      li.textContent = habit;
      habitsUl.appendChild(li);
    });
  }

  // 4. Medication Guidance Card
  const med = health.medication_guidance || {};
  const medUl = document.getElementById("med-points-list");
  if (medUl) {
    medUl.innerHTML = "";
    (med.points || [
      "Prescription Exclusivity: All medications, pharmaceutical tablets, and therapeutic dosages must be selected and prescribed solely by a qualified physician.",
      "No Automated Prescribing: Machine learning screening models estimate statistical likelihoods and never possess clinical authorization to recommend specific pharmaceuticals or dosages.",
      "Patient Safety Protocol: If you are currently taking prescribed medications, continue taking them exactly as instructed by your healthcare provider unless your doctor explicitly advises an adjustment."
    ]).forEach(pt => {
      const li = document.createElement("li");
      li.textContent = pt;
      medUl.appendChild(li);
    });
  }

  // 5. Doctor Consultation Advice Card
  const doc = health.doctor_consultation || {};
  const badgeEl = document.getElementById("doctor-urgency-badge");
  if (badgeEl) {
    badgeEl.textContent = doc.urgency || (pct >= 65 ? "Timely Clinical Evaluation" : "Routine Preventative Monitoring");
    if (pct >= 65) {
      badgeEl.style.backgroundColor = "#fee2e2";
      badgeEl.style.color = "#991b1b";
      badgeEl.style.borderColor = "#fca5a5";
    } else if (pct >= 35) {
      badgeEl.style.backgroundColor = "#fef3c7";
      badgeEl.style.color = "#92400e";
      badgeEl.style.borderColor = "#fcd34d";
    } else {
      badgeEl.style.backgroundColor = "#d1fae5";
      badgeEl.style.color = "#065f46";
      badgeEl.style.borderColor = "#6ee7b7";
    }
  }

  const docUl = document.getElementById("doctor-action-list");
  if (docUl) {
    docUl.innerHTML = "";
    (doc.action_plan || assessment.recommendations || []).forEach(act => {
      const li = document.createElement("li");
      li.textContent = act;
      docUl.appendChild(li);
    });
  }

  const crucialEl = document.getElementById("crucial-disease-notice");
  if (crucialEl) {
    crucialEl.textContent = doc.crucial_note || "";
    crucialEl.style.display = doc.crucial_note ? "block" : "none";
  }

  const lowRiskEl = document.getElementById("low-risk-reminder");
  if (lowRiskEl && doc.low_risk_disclaimer) {
    lowRiskEl.textContent = `* ${doc.low_risk_disclaimer}`;
  }

  // 6. Model Votes Breakdown
  modelVotesList.innerHTML = "";
  const allProbs = data.all_models_probabilities || {};
  Object.keys(allProbs).forEach(mName => {
    const p = (allProbs[mName] * 100).toFixed(0);
    const row = document.createElement("div");
    row.className = "vote-row";
    row.innerHTML = `
      <div class="vote-meta">
        <span class="vote-name">${mName}</span>
        <span class="vote-pct">${p}% Risk</span>
      </div>
      <div class="vote-track">
        <div class="vote-fill ${p >= 50 ? 'high' : ''}" style="width: ${p}%"></div>
      </div>
    `;
    modelVotesList.appendChild(row);
  });
}

async function downloadPdfReport() {
  const topBtn = document.getElementById("btn-download-pdf-top");
  const btmBtn = document.getElementById("btn-download-pdf-bottom");
  const originalText = "Download Official PDF Health Report";

  if (topBtn) topBtn.innerHTML = "<span>⏳ Generating PDF Report...</span>";
  if (btmBtn) btmBtn.innerHTML = "<span>⏳ Generating PDF Report...</span>";

  try {
    const payload = {
      dataset: activeDisease,
      features: latestFeatures || {},
      health_assessment: latestResultData ? latestResultData.health_assessment : null,
      all_models_probabilities: latestResultData ? latestResultData.all_models_probabilities : {},
      probability: latestResultData ? latestResultData.probability : 0.5,
      threshold: latestResultData ? latestResultData.threshold : 0.5
    };

    const res = await fetch("/api/download_pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const dateStr = new Date().toISOString().slice(0, 10);
      a.download = `Health_Assessment_Report_${activeDisease}_${dateStr}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } else {
      console.warn("Backend PDF generation returned non-OK, using print dialog fallback.");
      window.print();
    }
  } catch (err) {
    console.warn("PDF download request failed, activating print fallback:", err);
    window.print();
  } finally {
    if (topBtn) topBtn.innerHTML = `<span class="btn-pdf-icon">📥</span><span>${originalText}</span>`;
    if (btmBtn) btmBtn.innerHTML = `<span class="btn-pdf-icon">📥</span><span>${originalText}</span>`;
  }
}

function calculateLocalFallback(disease, f) {
  let p = 0.15;
  if (disease === "heart") {
    let score = 0;
    if (f.chol > 240) score += 2;
    if (f.trestbps > 140) score += 2;
    if (f.cp === 4) score += 2;
    if (f.exang === 1) score += 2;
    if (f.oldpeak > 1.5) score += 2;
    if (f.ca > 0) score += f.ca * 1.5;
    if (f.thal === 7) score += 2;
    p = Math.min(0.98, Math.max(0.08, score / 12));
  } else if (disease === "diabetes") {
    let score = 0;
    if (f.Glucose > 140) score += 4;
    if (f.BMI > 30) score += 2;
    if (f.Age > 45) score += 2;
    p = Math.min(0.95, Math.max(0.10, score / 9));
  } else {
    let radius = f.mean_radius || 14.0;
    p = Math.min(0.98, Math.max(0.04, (radius - 10) / 10));
  }

  const isHigh = p >= 0.5;
  const pct = Math.round(p * 100);

  const foodPrefer = disease === "diabetes"
    ? ["Non-Starchy Vegetables (spinach, broccoli, cauliflower)", "High-Fiber Whole Grains (oats, quinoa)", "Plant-Based Proteins & Legumes (lentils, chickpeas)", "Healthy Fats & Nuts (almonds, chia seeds, olive oil)"]
    : disease === "breast_cancer"
    ? ["Cruciferous Vegetables (broccoli, Brussels sprouts, cabbage)", "Antioxidant Berries (blueberries, raspberries, pomegranates)", "Clean Lean Proteins (lentils, beans, tofu, eggs, wild fish)", "Healthy Seeds & Whole Grains (ground flaxseeds, chia seeds)"]
    : ["Heart-Friendly Vegetables (leafy greens, carrots, tomatoes)", "Soluble-Fiber Whole Grains (rolled oats, barley)", "Omega-3 Fatty Acids (salmon, walnuts, flaxseeds)", "Cardiovascular Lipids (extra-virgin olive oil, avocados)"];

  const foodLimit = disease === "diabetes"
    ? ["Sugary Sodas, Syrups & Sweetened Juices", "Refined Carbohydrates (white bread, pastries)", "Packaged Candies & Added Table Sugars", "Deep-Fried Trans-Fat Snacks"]
    : disease === "breast_cancer"
    ? ["Ultra-Processed & Charred/Smoked Meats", "Excessive Refined Sugars & Pastries", "Alcoholic Beverages (oncology guidelines advise minimizing or eliminating)", "Hydrogenated Oils & Trans Fats"]
    : ["High-Sodium Canned Soups, Deli Cold-Cuts & Salted Chips", "Saturated Animal Fats (fatty red meats, full-fat butter)", "Commercial Bakery Trans Fats", "Excess Refined Sugars"];

  const mealIdeas = disease === "diabetes"
    ? ["Breakfast: Steel-cut oatmeal with chia seeds and raw walnuts", "Lunch: Mediterranean bowl with mixed greens, chickpeas, and olive oil vinaigrette", "Dinner: Baked wild salmon with steamed broccoli and quinoa"]
    : disease === "breast_cancer"
    ? ["Breakfast: Green antioxidant smoothie with baby spinach, berries, and chia seeds", "Lunch: Warm roasted vegetable and quinoa bowl with pumpkin seeds", "Dinner: Grilled salmon or baked tempeh with garlic-sautéed broccoli florets"]
    : ["Breakfast: Rolled oatmeal topped with fresh strawberries and ground flaxseeds", "Lunch: Mediterranean salad with cherry tomatoes, cucumbers, chicken, and olive oil", "Dinner: Oven-baked cod with steamed asparagus and brown rice"];

  const healthAssessment = {
    disease_key: disease,
    disease_title: disease === "heart" ? "Coronary Heart Disease Risk Assessment" : disease === "diabetes" ? "Diabetes Mellitus Metabolic Risk Assessment" : "Breast Cancer Cell Morphology Assessment",
    probability: p,
    probability_pct: pct,
    threshold: 0.5,
    is_high_risk: isHigh,
    category: isHigh ? (disease === "heart" ? "High Cardiovascular Risk" : disease === "breast_cancer" ? "High Malignancy Indication" : "Elevated Metabolic Risk") : "Low Disease Risk (Favorable Profile)",
    badge: isHigh ? "danger" : "success",
    headline: `Assessment indicates ${pct}% estimated disease risk likelihood.`,
    contributing_factors: isHigh ? ["One or more clinical measurements exceed safe thresholds."] : ["Test values fall within normal clinical guidelines."],
    food_recommendations: {
      prefer: foodPrefer,
      limit: foodLimit,
      meal_ideas: mealIdeas,
      disclaimer: "Dietary suggestions support general wellness; no food or diet can cure or prevent disease."
    },
    lifestyle_suggestions: {
      activity: isHigh ? "Engage in gentle 20 to 30 minutes of low-impact walking; obtain physician clearance prior to strenuous exertion." : "Aim for at least 150 minutes of moderate aerobic exercise weekly.",
      sleep: "Maintain 7 to 9 hours of consistent, uninterrupted nocturnal sleep nightly.",
      stress: "Practice 10-15 minutes of conscious stress regulation (box breathing or meditation) daily.",
      hydration: "Drink 2.0 to 2.5 liters of clean water daily unless restricted by your doctor.",
      smoking_alcohol: "Strictly avoid tobacco products and minimize or eliminate alcohol consumption.",
      habits_checklist: [
        "Track resting vitals regularly.",
        "Take a gentle 10-minute walk after meals.",
        "Maintain balanced sleep and hydration daily.",
        "Avoid smoking and excess alcohol."
      ]
    },
    medication_guidance: {
      title: "Medication Guidance",
      warning_note: "Do not start, stop, or change any medication without consulting your doctor.",
      points: [
        "Prescription Exclusivity: All medications and dosages must be prescribed solely by a qualified medical doctor.",
        "No Automated Prescribing: Machine learning screening models never prescribe or modify pharmaceuticals.",
        "Patient Safety Protocol: Continue taking any currently prescribed medicines as directed by your physician."
      ]
    },
    doctor_consultation: {
      urgency: isHigh ? "Timely Clinical Evaluation Recommended" : "Routine Preventative Health Monitoring",
      action_plan: isHigh ? [
        "Schedule a timely clinical evaluation with a specialist.",
        "Bring this screening report and recent blood tests to your appointment.",
        "Discuss appropriate confirmatory diagnostic tests."
      ] : [
        "Continue routine annual health checkups.",
        "Maintain periodic preventative screenings."
      ],
      crucial_note: disease === "breast_cancer" ? "CRITICAL NOTE: This model cannot replace clinical breast examination, mammography, ultrasound, or tissue biopsy." : "",
      low_risk_disclaimer: "Important: A low-risk result does not permanently rule out disease. Continue routine preventative checkups."
    },
    chosen_model: "Soft Voting Ensemble"
  };

  return {
    dataset: disease,
    probability: p,
    probability_pct: pct,
    prediction: isHigh ? 1 : 0,
    diagnosis: isHigh ? "Disease Likelihood Detected" : "Absence / Low Risk Detected",
    all_models_probabilities: {
      "Logistic Regression": p,
      "Decision Tree": isHigh ? 0.9 : 0.1,
      "Random Forest": p,
      "Gradient Boosting": p,
      "Soft Voting Ensemble": p
    },
    humanized_assessment: {
      category: healthAssessment.category,
      headline: healthAssessment.headline,
      badge: healthAssessment.badge,
      drivers: healthAssessment.contributing_factors,
      recommendations: healthAssessment.doctor_consultation.action_plan,
      urgency: healthAssessment.doctor_consultation.urgency
    },
    health_assessment: healthAssessment
  };
}
