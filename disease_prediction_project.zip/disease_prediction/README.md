# Smart Disease Prediction System with Model Ensemble
**Department of Artificial Intelligence & Machine Learning**  
*Project Review – I: Datasets, Algorithms, and Model Ensemble Design*

---

## 👥 Project Team & Mentorship
- **Students:** 24B11AI161, 24B11AI174, 24B11AI169, 24B11AI319
- **Faculty Guide:** G. Siva Sankar Sir

---

## 📌 Project Overview
The **Smart Disease Prediction System** is a data-driven machine learning framework that evaluates clinical risk by combining complementary algorithms into calibrated model ensembles. Adhering strictly to **Project Review – I** requirements, it introduces a reproducible pipeline with **zero data leakage**, rigorous **5-Fold Stratified Cross-Validation**, and clinically meaningful evaluation metrics.

---

## 📂 Project Architecture

```
disease_prediction/
├── data/
│   ├── heart_disease.csv            # UCI Cleveland dataset (303 records)
│   ├── breast_cancer.csv            # UCI Wisconsin Diagnostic (569 records)
│   └── diabetes.csv                 # Diabetes risk benchmark (768 records)
├── src/
│   ├── data_loader.py               # Dataset fetchers and schema metadata
│   ├── pipeline.py                  # Leakage-free ColumnTransformer pipelines
│   ├── models.py                    # Standalone candidate classifiers
│   ├── ensemble.py                  # Soft Voting & Stacking Ensembles
│   └── evaluation.py                # Clinical metrics, curves, and visualizers
├── static/                          # Fullstack Premium Frontend
│   ├── index.html                   # Interactive clinical UI
│   ├── style.css                    # Modern glassmorphism & responsive theme
│   └── app.js                       # Live predictions, presets, & charts
├── models/                          # Serialized production bundles (.joblib)
├── outputs/                         # ROC, PR, Calibration curves & CSVs
├── app.py                           # Fullstack Python REST API & web server
├── train_and_evaluate.py            # Automated multi-dataset benchmark runner
├── review_notebook.ipynb            # Interactive presentation Jupyter notebook
└── requirements.txt                 # Dependencies
```

---

## 🧠 Model Ensemble Progression (Slides 9 & 10)

1. **Linear Baseline:** *Logistic Regression* (transparent coefficients, calibrated probabilities).
2. **Rule-Based Baseline:** *Decision Tree* (explainable threshold paths, non-linear splits).
3. **Bagging Ensemble:** *Random Forest* (variance reduction, feature subspace aggregation).
4. **Boosting Ensemble:** *Gradient Boosting* (sequential residual correction for tabular data).
5. **Diversity Model:** *Support Vector Machine (RBF kernel)*.
6. **Primary Ensemble:** *Soft Voting Classifier* (calibrated probability averaging).
7. **Extension Ensemble:** *Stacking Classifier* (out-of-fold meta-learning with Logistic Regression).

---

## 📊 Evaluation Metrics (Slide 11)

- **Sensitivity (Recall):** Rate of true disease cases correctly flagged.
- **Specificity:** True Negative Rate (correctly identified healthy individuals).
- **ROC-AUC:** Discrimination ability across all potential decision cutoffs.
- **PR-AUC:** Precision-Recall curve area (robust under class imbalance).
- **F1-Score / Balanced Accuracy:** Class-aware summary metrics.
- **Brier Score:** Mean squared calibration error between predicted probabilities and observed outcomes.

---

## 🚀 How to Run the Project

### 1. Launch the Fullstack Web Application & API
To start the live interactive dashboard (patient risk predictor, model selector, consensus radar, and benchmark viewer):
```powershell
python app.py
```
Open your browser and navigate to:
👉 **`http://127.0.0.1:8000`**

### 2. Re-run Multi-Dataset Cross-Validation Benchmark
To re-train all models, compute 5-fold CV metrics, and regenerate all high-resolution charts in `outputs/`:
```powershell
python train_and_evaluate.py
```

### 3. Open the College Review Presentation Notebook
To run the step-by-step notebook for viva / panel review:
```powershell
jupyter notebook review_notebook.ipynb
```

---

## 🛡️ Research Disclaimer
This system is an academic research prototype designed for comparative machine learning benchmarking. It does not replace certified professional medical diagnostics or clinical judgment.
