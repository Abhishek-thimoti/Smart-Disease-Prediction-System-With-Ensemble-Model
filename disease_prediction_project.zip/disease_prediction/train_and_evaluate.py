"""
Train and Evaluate Runner
Executes multi-dataset benchmark comparison for Project Review - I:
1. Evaluates all models (Logistic Regression, Decision Tree, Random Forest, Gradient Boosting, SVM, Soft Voting, Stacking)
2. Computes all Slide 11 metrics with 5-fold Stratified Cross-Validation
3. Generates publication-ready ROC, PR, Calibration, and Bar charts
4. Serializes trained production pipelines into models/
5. Exports JSON & Markdown summaries
"""

import os
import json
import joblib
import pandas as pd
from src.data_loader import get_dataset
from src.ensemble import get_all_pipelines
from src.evaluation import (
    evaluate_cv, plot_roc_curves, plot_pr_curves,
    plot_calibration_curves, plot_metrics_comparison_bar
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
MODELS_DIR = os.path.join(BASE_DIR, "models")
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)


def run_benchmark_for_dataset(dataset_key="heart", display_name="Heart Disease (Cleveland)"):
    print(f"\n{'='*70}")
    print(f"BENCHMARK RUN: {display_name.upper()}")
    print(f"{'='*70}")

    # 1. Load Data
    X, y, num_cols, cat_cols, metadata = get_dataset(dataset_key)
    print(f"Dataset Loaded: {len(X)} instances, {len(X.columns)} features (Target prevalence: {y.mean():.1%})")

    # 2. Build Pipeline Pool
    models = get_all_pipelines(num_cols, cat_cols)

    # 3. Stratified 5-Fold Cross Validation
    print("Running 5-Fold Stratified Cross-Validation across all models...")
    summary_df, detailed_df, oof_preds = evaluate_cv(models, X, y, n_splits=5, random_state=42)

    # Clean summary format for reporting
    clean_rows = []
    for model_name in summary_df.index:
        row = {"Model": model_name}
        for metric in ["Sensitivity (Recall)", "Specificity", "F1-Score", "ROC-AUC", "PR-AUC", "Brier Score", "Accuracy"]:
            mean_val = summary_df.loc[model_name, (metric, "mean")]
            std_val = summary_df.loc[model_name, (metric, "std")]
            row[metric] = f"{mean_val:.3f} ± {std_val:.3f}"
            row[f"{metric}_mean"] = round(mean_val, 4)
        clean_rows.append(row)

    benchmark_table = pd.DataFrame(clean_rows)
    print("\n--- Cross-Validation Benchmark Results ---")
    print(benchmark_table[["Model", "Sensitivity (Recall)", "Specificity", "F1-Score", "ROC-AUC", "Brier Score"]].to_string(index=False))

    # Save CSV
    csv_path = os.path.join(OUTPUT_DIR, f"benchmark_{dataset_key}.csv")
    benchmark_table.to_csv(csv_path, index=False)

    # 4. Generate & Save Visual Plots
    print("\nGenerating evaluation charts...")
    plot_roc_curves(oof_preds, y, display_name, os.path.join(OUTPUT_DIR, f"roc_{dataset_key}.png"))
    plot_pr_curves(oof_preds, y, display_name, os.path.join(OUTPUT_DIR, f"pr_{dataset_key}.png"))
    plot_calibration_curves(oof_preds, y, display_name, os.path.join(OUTPUT_DIR, f"calibration_{dataset_key}.png"))
    plot_metrics_comparison_bar(detailed_df, display_name, os.path.join(OUTPUT_DIR, f"comparison_bar_{dataset_key}.png"))

    # 5. Fit full pipelines and serialize for real-time web inference
    print("Fitting production models on complete dataset...")
    fitted_models = {}
    for name, model in models.items():
        model.fit(X, y)
        fitted_models[name] = model

    # Save model artifact bundle
    bundle_path = os.path.join(MODELS_DIR, f"{dataset_key}_bundle.joblib")
    bundle_data = {
        "dataset_key": dataset_key,
        "display_name": display_name,
        "models": fitted_models,
        "num_cols": num_cols,
        "cat_cols": cat_cols,
        "metadata": metadata,
        "benchmark_summary": clean_rows,
        "sample_row": X.iloc[0].to_dict()
    }
    joblib.dump(bundle_data, bundle_path)
    print(f"Saved production model bundle -> {bundle_path}")

    return {
        "dataset_key": dataset_key,
        "display_name": display_name,
        "instances": len(X),
        "features": len(X.columns),
        "prevalence": round(float(y.mean()), 3),
        "benchmark_table": clean_rows
    }


def main():
    print("="*70)
    print("SMART DISEASE PREDICTION SYSTEM - BENCHMARK PIPELINE")
    print("Review-I Specification: Baselines, Bagging, Boosting, and Ensembles")
    print("="*70)

    datasets = [
        ("heart", "UCI Heart Disease (Cleveland)"),
        ("breast_cancer", "UCI Breast Cancer Wisconsin (Diagnostic)"),
        ("diabetes", "Diabetes Risk Benchmark")
    ]

    all_results = {}
    for key, name in datasets:
        all_results[key] = run_benchmark_for_dataset(key, name)

    # Save global benchmark JSON for frontend API
    json_path = os.path.join(OUTPUT_DIR, "benchmark_summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2)
    print(f"\nAll benchmark summaries saved to: {json_path}")
    print("\nBENCHMARK RUN COMPLETED SUCCESSFULLY!")


if __name__ == "__main__":
    main()
