"""
Candidate Model Pool
Implements baseline, bagging, boosting, and diversity learners per Slide 9:
1. Logistic Regression (Linear interpretable baseline)
2. Decision Tree (Nonlinear rule-based baseline)
3. Random Forest (Bagging ensemble, variance reduction)
4. Gradient Boosting (Sequential boosting ensemble)
5. Support Vector Machine (RBF kernel, diversity learner)
"""

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC


def get_candidate_models(random_state=42):
    """
    Returns the portfolio of candidate learners specified in Review - I.
    """
    models = {
        "Logistic Regression": LogisticRegression(
            C=1.0,
            max_iter=1000,
            solver="lbfgs",
            random_state=random_state
        ),
        "Decision Tree": DecisionTreeClassifier(
            max_depth=5,
            min_samples_split=8,
            min_samples_leaf=4,
            random_state=random_state
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=120,
            max_depth=6,
            min_samples_split=6,
            random_state=random_state
        ),
        "Gradient Boosting": GradientBoostingClassifier(
            n_estimators=100,
            learning_rate=0.08,
            max_depth=3,
            subsample=0.9,
            random_state=random_state
        ),
        "Support Vector Machine": SVC(
            C=1.0,
            kernel="rbf",
            probability=True,
            random_state=random_state
        )
    }
    return models
