"""
Preprocessing and Leakage Control Pipeline
Adheres to Slide 8:
- One pipeline per model.
- Transformers fit strictly on training folds to prevent data leakage.
- Handles mixed-type features, missingness via median/most_frequent imputation,
  one-hot encoding for nominal categories, and standardization.
"""

from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder


def build_preprocessor(numeric_cols, categorical_cols):
    """
    Constructs a ColumnTransformer that guarantees zero data leakage:
    - Numeric features: Median imputation + StandardScaler
    - Categorical features: Most-frequent imputation + OneHotEncoder
    """
    transformers = []

    if numeric_cols:
        num_pipeline = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler())
        ])
        transformers.append(("num", num_pipeline, numeric_cols))

    if categorical_cols:
        cat_pipeline = Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
        ])
        transformers.append(("cat", cat_pipeline, categorical_cols))

    preprocessor = ColumnTransformer(
        transformers=transformers,
        remainder="drop"  # Drop unlisted columns (e.g., IDs, metadata)
    )
    return preprocessor


def build_model_pipeline(model, numeric_cols, categorical_cols):
    """
    Wraps the feature preprocessor and candidate classifier into a single scikit-learn Pipeline.
    Ensures that when cross-validation runs, all preprocessing parameters are fit solely on train splits.
    """
    preprocessor = build_preprocessor(numeric_cols, categorical_cols)
    pipeline = Pipeline([
        ("preprocessor", preprocessor),
        ("classifier", model)
    ])
    return pipeline
