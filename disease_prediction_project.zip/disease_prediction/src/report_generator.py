"""
PDF Health Report Generator for Smart Disease Prediction System
Generates a professional, multi-page, publication-quality printable PDF health report using ReportLab.
"""

import io
import datetime
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY


def build_pdf_health_report(assessment_data, patient_features, metadata_info=None):
    """
    Builds a professional PDF document from prediction results and clinical guidance.
    Returns bytes of the generated PDF.
    """
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()

    # Custom typography styles
    header_title_style = ParagraphStyle(
        'HeaderTitle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#0f172a'),
        alignment=TA_LEFT
    )

    header_sub_style = ParagraphStyle(
        'HeaderSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=13,
        textColor=colors.HexColor('#64748b'),
        alignment=TA_LEFT
    )

    section_heading = ParagraphStyle(
        'SectionHeading',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor('#1e3a8a'),
        spaceBefore=10,
        spaceAfter=5
    )

    body_style = ParagraphStyle(
        'BodyTextCustom',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=13,
        textColor=colors.HexColor('#334155'),
        alignment=TA_LEFT
    )

    bullet_style = ParagraphStyle(
        'BulletCustom',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        leading=12.5,
        textColor=colors.HexColor('#334155'),
        leftIndent=12
    )

    warning_text_style = ParagraphStyle(
        'WarningText',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9.5,
        leading=13.5,
        textColor=colors.HexColor('#991b1b'),
        alignment=TA_CENTER
    )

    disclaimer_style = ParagraphStyle(
        'DisclaimerText',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=7.5,
        leading=10.5,
        textColor=colors.HexColor('#64748b'),
        alignment=TA_JUSTIFY
    )

    story = []

    # 1. Hospital / Clinic Branding Header
    brand_table_data = [
        [
            Paragraph("<b>SMART DISEASE PREDICTION SYSTEM</b><br/><font color='#64748b' size='8'>Clinical Decision Support & Health Guidance Platform</font>", header_title_style),
            Paragraph(f"<b>REPORT DATE:</b> {datetime.datetime.now().strftime('%B %d, %Y - %I:%M %p')}<br/><b>STATUS:</b> OFFICIAL SCREENING REPORT", ParagraphStyle('DateRight', parent=body_style, alignment=TA_RIGHT, fontSize=8))
        ]
    ]
    brand_table = Table(brand_table_data, colWidths=[340, 192])
    brand_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(brand_table)
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#2563eb'), spaceBefore=6, spaceAfter=10))

    # 2. Assessment Summary Card (Risk Gauge Banner)
    disease_title = assessment_data.get('disease_title', 'Disease Risk Assessment')
    prob_pct = assessment_data.get('probability_pct', 0.0)
    category = assessment_data.get('category', 'Risk Assessment Complete')
    is_high = assessment_data.get('is_high_risk', False)

    if prob_pct >= 65:
        banner_bg = colors.HexColor('#fef2f2')
        banner_border = colors.HexColor('#ef4444')
        banner_text_color = colors.HexColor('#991b1b')
        status_tag = "HIGH RISK ALERT"
    elif prob_pct >= 35:
        banner_bg = colors.HexColor('#fffbeb')
        banner_border = colors.HexColor('#f59e0b')
        banner_text_color = colors.HexColor('#92400e')
        status_tag = "MEDIUM RISK (CAUTION)"
    else:
        banner_bg = colors.HexColor('#ecfdf5')
        banner_border = colors.HexColor('#10b981')
        banner_text_color = colors.HexColor('#065f46')
        status_tag = "LOW RISK (FAVORABLE)"

    gauge_cell_1 = Paragraph(
        f"<font size='10' color='#64748b'>TARGET MODULE</font><br/>"
        f"<b><font size='13' color='#0f172a'>{disease_title.upper()}</font></b><br/>"
        f"<font size='9' color='#334155'>Clinical Evaluation Model: <b>{assessment_data.get('chosen_model', 'Soft Voting Ensemble')}</b></font>",
        body_style
    )

    gauge_cell_2 = Paragraph(
        f"<font size='8' color='{banner_text_color.hexval()}'><b>[ {status_tag} ]</b></font><br/>"
        f"<b><font size='22' color='{banner_text_color.hexval()}'>{prob_pct}%</font></b><br/>"
        f"<font size='9' color='#334155'><b>{category}</b></font>",
        ParagraphStyle('RiskCell', parent=body_style, alignment=TA_CENTER)
    )

    summary_table = Table([[gauge_cell_1, gauge_cell_2]], colWidths=[360, 172])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), banner_bg),
        ('BOX', (0, 0), (-1, -1), 1.5, banner_border),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 10))

    # 3. Patient Vitals and Lab Data Table
    story.append(Paragraph("1. Patient Test Values & Laboratory Inputs", section_heading))
    
    # Format features into a clean 2-column or 4-cell table
    feature_rows = [["Test Parameter", "Recorded Value", "Test Parameter", "Recorded Value"]]
    items = list(patient_features.items())
    
    friendly_names = {
        "age": "Patient Age", "sex": "Biological Sex", "cp": "Chest Pain Type",
        "trestbps": "Resting Blood Pressure", "chol": "Serum Cholesterol", "fbs": "Fasting Blood Sugar",
        "restecg": "Resting ECG Result", "thalach": "Max Heart Rate", "exang": "Exercise Angina",
        "oldpeak": "ST Depression (mm)", "slope": "ST Slope", "ca": "Blocked Major Vessels",
        "thal": "Thalassemia Scan", "Age": "Patient Age", "Glucose": "Plasma Glucose",
        "BloodPressure": "Diastolic Blood Pressure", "SkinThickness": "Skinfold Thickness",
        "Insulin": "2-Hour Serum Insulin", "BMI": "Body Mass Index (BMI)",
        "DiabetesPedigreeFunction": "Diabetes Pedigree Score", "Pregnancies": "Pregnancies",
        "mean_radius": "Mean Cell Radius", "mean_texture": "Mean Cell Texture",
        "mean_perimeter": "Mean Perimeter", "mean_area": "Mean Cell Area",
        "mean_smoothness": "Mean Smoothness", "mean_concavity": "Mean Concavity"
    }

    formatted_pairs = []
    for k, v in items:
        label = friendly_names.get(k, k.replace('_', ' ').title())
        # Format values nicely
        if k == "sex":
            val_str = "Male" if str(v) in ["1", "1.0"] else "Female"
        elif k == "fbs":
            val_str = "> 120 mg/dL (High)" if str(v) in ["1", "1.0"] else "<= 120 mg/dL (Normal)"
        elif k == "exang":
            val_str = "Yes (Exercise Pain)" if str(v) in ["1", "1.0"] else "No"
        elif isinstance(v, float):
            val_str = f"{v:.2f}" if v != int(v) else f"{int(v)}"
        else:
            val_str = str(v)
        formatted_pairs.append((label, val_str))

    for i in range(0, len(formatted_pairs), 2):
        col1_label, col1_val = formatted_pairs[i]
        if i + 1 < len(formatted_pairs):
            col2_label, col2_val = formatted_pairs[i + 1]
        else:
            col2_label, col2_val = "-", "-"
        feature_rows.append([col1_label, col1_val, col2_label, col2_val])

    vitals_table = Table(feature_rows, colWidths=[160, 106, 160, 106])
    vitals_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f1f5f9')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.HexColor('#0f172a')),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3.5),
        ('TOPPADDING', (0, 0), (-1, -1), 3.5),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
        ('ALIGN', (1, 1), (1, -1), 'CENTER'),
        ('ALIGN', (3, 1), (3, -1), 'CENTER'),
    ]))
    story.append(vitals_table)
    story.append(Spacer(1, 10))

    # 4. Key Contributing Factors
    story.append(Paragraph("2. Key Contributing Diagnostic Factors", section_heading))
    drivers = assessment_data.get('contributing_factors', [])
    if drivers:
        for d in drivers:
            story.append(Paragraph(f"• <b>{d}</b>", bullet_style))
    else:
        story.append(Paragraph("• All evaluated test parameters fall within expected physiological ranges.", bullet_style))
    story.append(Spacer(1, 10))

    # 5. Personalized Food Recommendations
    story.append(Paragraph("3. Personalized Dietary & Nutritional Guidance", section_heading))
    food = assessment_data.get('food_recommendations', {})
    
    food_table_data = [
        [
            Paragraph("<b>FOODS TO PREFER</b>", ParagraphStyle('PrefTitle', parent=body_style, fontName='Helvetica-Bold', textColor=colors.HexColor('#065f46'))),
            Paragraph("<b>FOODS TO LIMIT</b>", ParagraphStyle('LimitTitle', parent=body_style, fontName='Helvetica-Bold', textColor=colors.HexColor('#991b1b')))
        ]
    ]

    pref_content = "<br/>".join([f"✔ {item}" for item in food.get('prefer', [])])
    limit_content = "<br/>".join([f"✖ {item}" for item in food.get('limit', [])])

    food_table_data.append([
        Paragraph(pref_content, bullet_style),
        Paragraph(limit_content, bullet_style)
    ])

    food_table = Table(food_table_data, colWidths=[266, 266])
    food_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, 0), colors.HexColor('#ecfdf5')),
        ('BACKGROUND', (1, 0), (1, 0), colors.HexColor('#fef2f2')),
        ('BACKGROUND', (0, 1), (0, 1), colors.HexColor('#fcfdfd')),
        ('BACKGROUND', (1, 1), (1, 1), colors.HexColor('#fcfcfc')),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    story.append(food_table)
    story.append(Spacer(1, 6))

    # Simple Meal Ideas
    meal_ideas = food.get('meal_ideas', [])
    if meal_ideas:
        story.append(Paragraph("<b>Practical Daily Meal Suggestions:</b>", ParagraphStyle('MealHead', parent=body_style, fontName='Helvetica-Bold', fontSize=8.5)))
        for meal in meal_ideas:
            story.append(Paragraph(f"• {meal}", bullet_style))
    story.append(Spacer(1, 4))
    story.append(Paragraph(f"<i>Disclaimer: {food.get('disclaimer', '')}</i>", disclaimer_style))
    story.append(Spacer(1, 10))

    # 6. Personalized Lifestyle Suggestions
    story.append(Paragraph("4. Personalized Lifestyle & Habit Recommendations", section_heading))
    life = assessment_data.get('lifestyle_suggestions', {})
    
    life_points = [
        f"<b>Physical Activity:</b> {life.get('activity', '')}",
        f"<b>Restorative Sleep:</b> {life.get('sleep', '')}",
        f"<b>Stress Management:</b> {life.get('stress', '')}",
        f"<b>Hydration:</b> {life.get('hydration', '')}",
        f"<b>Smoking & Alcohol:</b> {life.get('smoking_alcohol', '')}"
    ]
    for pt in life_points:
        story.append(Paragraph(f"• {pt}", bullet_style))

    story.append(Spacer(1, 10))

    # 7. Medication Guidance (Prominent Callout Box)
    story.append(Paragraph("5. Medication Guidance", section_heading))
    med = assessment_data.get('medication_guidance', {})
    
    warning_box_data = [[
        Paragraph(
            f"<b>CRITICAL PATIENT SAFETY NOTICE:</b><br/>"
            f"<font size='10' color='#b91c1c'><b>“{med.get('warning_note', 'Do not start, stop, or change any medication without consulting your doctor.')}”</b></font>",
            warning_text_style
        )
    ]]
    warning_table = Table(warning_box_data, colWidths=[532])
    warning_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fee2e2')),
        ('BOX', (0, 0), (-1, -1), 1.5, colors.HexColor('#ef4444')),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('LEFTPADDING', (0, 0), (-1, -1), 14),
        ('RIGHTPADDING', (0, 0), (-1, -1), 14),
    ]))
    story.append(warning_table)
    story.append(Spacer(1, 6))

    for pt in med.get('points', []):
        story.append(Paragraph(f"• {pt}", bullet_style))
    story.append(Spacer(1, 10))

    # 8. Doctor Consultation Advice
    story.append(Paragraph("6. Professional Doctor Consultation Advice", section_heading))
    doc_guide = assessment_data.get('doctor_consultation', {})
    
    story.append(Paragraph(f"<b>Clinical Urgency Level:</b> {doc_guide.get('urgency', 'Consultation Recommended')}", ParagraphStyle('DocUrg', parent=body_style, fontName='Helvetica-Bold')))
    for action in doc_guide.get('action_plan', []):
        story.append(Paragraph(f"✔ {action}", bullet_style))
    story.append(Spacer(1, 4))
    
    # Crucial disease specific note
    crucial = doc_guide.get('crucial_note', '')
    if crucial:
        story.append(Paragraph(f"<b>Specialized Advisory:</b> {crucial}", ParagraphStyle('CrucialNote', parent=body_style, textColor=colors.HexColor('#1e40af'), fontSize=8.5)))
    
    story.append(Spacer(1, 4))
    story.append(Paragraph(f"<i>{doc_guide.get('low_risk_disclaimer', '')}</i>", disclaimer_style))
    story.append(Spacer(1, 12))

    # 9. Multi-Model Ensemble Transparency Table
    all_models = assessment_data.get('all_models_probabilities', {})
    if all_models:
        story.append(Paragraph("7. Multi-Algorithm Machine Learning Consensus Breakdown", section_heading))
        model_rows = [["Algorithm", "Predicted Disease Risk (%)", "Algorithm", "Predicted Disease Risk (%)"]]
        m_list = list(all_models.items())
        for i in range(0, len(m_list), 2):
            m1_name, m1_p = m_list[i]
            if i + 1 < len(m_list):
                m2_name, m2_p = m_list[i + 1]
            else:
                m2_name, m2_p = "-", "-"
            
            p1_str = f"{m1_p * 100:.1f}%" if isinstance(m1_p, (int, float)) else str(m1_p)
            p2_str = f"{m2_p * 100:.1f}%" if isinstance(m2_p, (int, float)) else str(m2_p)
            model_rows.append([m1_name, p1_str, m2_name, p2_str])

        model_table = Table(model_rows, colWidths=[180, 86, 180, 86])
        model_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f8fafc')),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
            ('ALIGN', (1, 1), (1, -1), 'CENTER'),
            ('ALIGN', (3, 1), (3, -1), 'CENTER'),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ]))
        story.append(model_table)
        story.append(Spacer(1, 12))

    # 10. Footer Disclaimer
    story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#cbd5e1'), spaceBefore=8, spaceAfter=8))
    legal_disclaimer = (
        "CONFIDENTIAL MEDICAL SCREENING NOTICE: This health assessment report was generated by the Smart Disease Prediction System "
        "as an educational and clinical decision-support tool. Machine learning predictions are based on statistical population patterns "
        "and do NOT constitute an official clinical diagnosis, pathology report, or therapeutic prescription. Always consult a qualified "
        "physician, oncologist, or healthcare specialist for professional diagnosis, medication, or medical treatment."
    )
    story.append(Paragraph(legal_disclaimer, disclaimer_style))

    doc.build(story)
    return buffer.getvalue()
