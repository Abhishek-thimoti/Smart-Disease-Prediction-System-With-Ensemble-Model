"""
Ensemble Architecture Module
Implements the multi-model ensemble designs specified in Slide 10:
1. Primary: Soft Voting Classifier (calibrated probability averaging)
2. Extension: Stacking Classifier (out-of-fold predictions into Logistic Regression meta-learner)
3. Calibration Layer: CalibratedClassifierCV to minimize Brier calibration error
"""

from sklearn.ensemble import VotingClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
from src.pipeline import build_model_pipeline
from src.models import get_candidate_models


def build_soft_voting_ensemble(base_pipelines, weights=None):
    """
    Constructs a Soft Voting ensemble combining predicted probability vectors.
    """
    estimators = [(name.lower().replace(" ", "_"), pipe) for name, pipe in base_pipelines.items()]
    voting_clf = VotingClassifier(
        estimators=estimators,
        voting="soft",
        weights=weights,
        n_jobs=-1
    )
    return voting_clf


def build_stacking_ensemble(base_pipelines, meta_learner=None, cv=5):
    """
    Constructs a Stacking Classifier using out-of-fold cross-validation predictions.
    Meta-learner: Logistic Regression (interpretable blend of base model probabilities).
    """
    estimators = [(name.lower().replace(" ", "_"), pipe) for name, pipe in base_pipelines.items()]
    if meta_learner is None:
        meta_learner = LogisticRegression(C=1.0, max_iter=500, random_state=42)

    stacking_clf = StackingClassifier(
        estimators=estimators,
        final_estimator=meta_learner,
        cv=cv,
        stack_method="predict_proba",
        passthrough=False,
        n_jobs=-1
    )
    return stacking_clf


def get_all_pipelines(numeric_cols, categorical_cols):
    """
    Returns the complete set of experimental models ready for comparison:
    - Standalone: Logistic Regression, Decision Tree, Random Forest, Gradient Boosting, SVM
    - Ensembles: Soft Voting Ensemble, Stacking Ensemble
    """
    candidates = get_candidate_models()
    
    # Build standalone pipelines
    standalone_pipes = {}
    for name, model in candidates.items():
        standalone_pipes[name] = build_model_pipeline(model, numeric_cols, categorical_cols)

    # Core 4 learners for ensemble pool (as specified in Slide 9 & 10)
    core_names = ["Logistic Regression", "Decision Tree", "Random Forest", "Gradient Boosting"]
    core_pipes = {k: standalone_pipes[k] for k in core_names}

    # Primary ensemble: Soft Voting (equal probability aggregation)
    voting_ensemble = build_soft_voting_ensemble(core_pipes)
    
    # Extension ensemble: Stacking
    stacking_ensemble = build_stacking_ensemble(core_pipes, cv=5)

    all_models = dict(standalone_pipes)
    all_models["Soft Voting Ensemble"] = voting_ensemble
    all_models["Stacking Ensemble"] = stacking_ensemble

    return all_models
