"""
Health Guidance Engine for Smart Disease Prediction System
Generates personalized food recommendations, lifestyle modifications,
responsible medication guidelines, and doctor consultation advice.
Educational and screening-support tool only; does not provide formal medical diagnoses or prescriptions.
"""

def get_food_recommendations(disease_key, is_high_risk, features):
    """
    Returns disease-tailored food recommendations including foods to prefer,
    foods to limit, simple meal ideas, and non-curative disclaimers.
    """
    if disease_key == "diabetes":
        prefer = [
            "Non-Starchy Vegetables: Spinach, kale, broccoli, cauliflower, cucumbers, and bell peppers (minimal blood glucose impact).",
            "High-Fiber Whole Grains: Steel-cut oats, quinoa, brown rice, and barley to slow glucose absorption.",
            "Plant-Based Proteins & Legumes: Lentils, chickpeas, black beans, and edamame for sustained satiety.",
            "Healthy Fats & Nuts: Raw almonds, walnuts, chia seeds, and extra-virgin olive oil.",
            "Lean Protein Sources: Skinless poultry, eggs, and omega-3 rich fatty fish (salmon, mackerel, sardines)."
        ]
        limit = [
            "Sugary Beverages: Regular sodas, sweetened fruit juices, energy drinks, and sweetened coffee beverages.",
            "Refined Carbohydrates: White bread, refined flour pasta, pastries, commercial cookies, and breakfast candies.",
            "Added Sugars & Syrups: Table sugar, high-fructose corn syrup, molasses, and confectioneries.",
            "Processed Snack Foods: Potato chips, deep-fried fast foods, and trans-fat containing bakery goods."
        ]
        meal_ideas = [
            "Breakfast: Warm steel-cut oatmeal cooked in water or unsweetened almond milk, topped with 1 tbsp chia seeds and a small handful of raw walnuts.",
            "Lunch: Mediterranean bowl with mixed leafy greens, 1/2 cup chickpeas, sliced cucumbers, grilled chicken breast or tofu, and extra virgin olive oil vinaigrette.",
            "Dinner: Baked wild salmon or spiced lentil curry accompanied by generous steamed broccoli and 1/3 cup of fluffy quinoa.",
            "Snack (if needed): Crisp celery or cucumber sticks dipped in 2 tablespoons of traditional hummus."
        ]
        disclaimer = "Nutritional suggestions support general glycemic control and steady energy; no food or diet can cure or reverse diabetes."

    elif disease_key == "breast_cancer":
        prefer = [
            "Cruciferous Vegetables: Broccoli, Brussels sprouts, cabbage, and cauliflower (rich in glucosinolates and cellular protective antioxidants).",
            "Polyphenol-Rich Fruits: Deeply pigmented berries (blueberries, blackberries, raspberries) and pomegranates.",
            "Clean Protein Sources: Lentils, beans, organic tofu, eggs, and wild-caught fish to preserve cellular repair and lean mass.",
            "Anti-Inflammatory Dietary Fibers: Ground flaxseeds, chia seeds, and whole oats.",
            "Healthy Hydrating Liquids: Fresh water, green tea, and unsweetened herbal infusions."
        ]
        limit = [
            "Ultra-Processed & Charred Meats: Bacon, hot dogs, sausages, and heavily charred or smoked meats (contain heterocyclic amines).",
            "Excessive Refined Sugars: Pastries, sugary desserts, and sweetened commercial snacks.",
            "Alcoholic Beverages: Medical oncology guidelines strongly advise minimizing or eliminating alcohol, an established risk factor in breast tissue proliferation.",
            "Hydrogenated & Trans Fats: Deep-fried commercial fast foods and packaged snack cakes."
        ]
        meal_ideas = [
            "Breakfast: Vibrant green antioxidant smoothie with baby spinach, 1/2 cup frozen blueberries, 1 tbsp ground flaxseeds, and unsweetened almond milk.",
            "Lunch: Warm roasted vegetable and quinoa bowl with chickpeas, pumpkin seeds, and a light lemon-tahini dressing.",
            "Dinner: Grilled wild salmon or seasoned baked tempeh with garlic-sautéed broccoli florets and half a baked sweet potato.",
            "Snack (if needed): A small palmful of raw walnuts paired with a cup of warm brewed green tea."
        ]
        disclaimer = "Nutritional guidance provides supportive cellular vitality, balanced energy, and general wellness; it is not a cancer treatment or substitute for oncology care."

    else:  # heart disease
        prefer = [
            "Heart-Friendly Vegetables: Leafy greens (spinach, Swiss chard, arugula), tomatoes (rich in lycopene), and steamed carrots.",
            "Soluble-Fiber Whole Grains: Rolled oats, barley, and whole wheat to assist in lowering LDL cholesterol.",
            "Omega-3 Fatty Acids: Cold-water fish (salmon, tuna, sardines) or plant-based flaxseeds and chia seeds.",
            "Antioxidant-Rich Fruits: Fresh berries, apples, pears, and citrus fruits.",
            "Cardiovascular Healthy Lipids: Extra-virgin olive oil, avocados, and raw unsalted nuts."
        ]
        limit = [
            "High-Sodium Foods: Table salt, processed deli cold-cuts, canned commercial soups, and salty packaged chips (target < 2,000 mg sodium daily).",
            "Saturated Animal Fats: Fatty red meats, full-fat butter, lard, and high-fat cheeses.",
            "Trans Fats: Partially hydrogenated oils, commercial bakery frostings, and commercial frying oils.",
            "Excess Refined Sugars: Sweetened sodas, packaged desserts, and candy that increase systemic triglycerides."
        ]
        meal_ideas = [
            "Breakfast: Rolled oatmeal prepared with water or skim milk, topped with fresh sliced strawberries and 1 tablespoon of ground flaxseeds.",
            "Lunch: Heart-healthy Mediterranean salad with mixed greens, cherry tomatoes, cucumbers, grilled chicken breast or beans, olive oil, and lemon.",
            "Dinner: Oven-baked cod or lentil stew served with steamed asparagus and a moderate serving of brown rice.",
            "Snack (if needed): Sliced crisp apple with one tablespoon of unsalted natural peanut butter."
        ]
        disclaimer = "Cardiovascular nutrition supports arterial health and balanced lipid profiles; it does not replace physician-prescribed cardiovascular therapies."

    return {
        "prefer": prefer,
        "limit": limit,
        "meal_ideas": meal_ideas,
        "disclaimer": disclaimer
    }


def get_lifestyle_suggestions(disease_key, is_high_risk, features):
    """
    Returns evidence-based lifestyle modifications spanning physical activity,
    sleep, stress reduction, hydration, and habit checklists.
    """
    if is_high_risk:
        activity = (
            "Engage in low-to-moderate physical activity (such as 20 to 30 minutes of gentle walking or light stretching). "
            "Avoid sudden high-intensity or unaccustomed strenuous exercise until formally evaluated and cleared by your physician."
        )
    else:
        activity = (
            "Aim for at least 150 minutes of moderate-intensity aerobic physical activity per week (such as brisk walking, "
            "cycling, or swimming), paired with 2 sessions of light muscle-strengthening exercises."
        )

    if disease_key == "diabetes":
        specific_habits = [
            "Post-Meal Movement: Take a gentle 10-15 minute walk after meals to blunt postprandial glucose spikes.",
            "Consistent Sleep Schedule: Secure 7–8 hours of restful sleep nightly to maintain healthy insulin sensitivity.",
            "Stress Regulation: Practice daily 10-minute mindfulness breathing to prevent stress-induced cortisol rises.",
            "Hydration Target: Drink 2 to 2.5 liters of pure water daily; strictly avoid liquid sugars.",
            "Tobacco & Alcohol: Complete smoking cessation is vital to avoid diabetic vascular damage; avoid binge alcohol consumption."
        ]
    elif disease_key == "breast_cancer":
        specific_habits = [
            "Gentle Daily Mobility: Practice daily 20–30 minutes of walking, yoga, or stretching to support lymphatic circulation.",
            "Restorative Rest: Ensure 7–9 hours of sleep in a cool, dark room to support nocturnal cellular repair.",
            "Mind-Body Care: Practice stress reduction through journaling, meditation, or supportive counseling.",
            "Clean Hydration: Maintain consistent water intake of 2 to 2.5 liters daily.",
            "Environmental Prudence: Avoid tobacco products and eliminate alcohol consumption to reduce tissue oxidative stress."
        ]
    else:  # heart disease
        specific_habits = [
            "Routine Vitals Tracking: Log resting blood pressure and resting pulse at home once or twice weekly.",
            "Gradual Aerobic Exercise: Maintain regular low-impact walking; pause immediately if chest tightness or dizziness occurs.",
            "Quality Sleep: Maintain 7–8 hours of sleep; consult a doctor if loud snoring or daytime sleepiness indicates sleep apnea.",
            "Sodium & Hydration: Maintain consistent hydration with water while keeping table salt to less than 1 level teaspoon daily.",
            "Strict Smoking Cessation: Avoid all tobacco and nicotine products, which acutely constrict coronary arteries and elevate pulse."
        ]

    return {
        "activity": activity,
        "sleep": "Maintain 7 to 9 hours of consistent, uninterrupted nocturnal sleep to promote hormonal balance and cardiovascular recovery.",
        "stress": "Practice 10–15 minutes of conscious stress-reduction daily (box breathing, progressive muscle relaxation, or quiet meditation).",
        "hydration": "Drink 2.0 to 2.5 liters of clean water daily unless your physician has placed you on a specific fluid-restriction protocol.",
        "smoking_alcohol": "Strictly avoid smoking and tobacco usage. Limit or eliminate alcohol consumption to safeguard metabolic and vascular health.",
        "habits_checklist": specific_habits
    }


def get_medication_guidance(disease_key):
    """
    Returns responsible, safe medication guidance emphasizing physician oversight.
    Strictly avoids prescribing medications or altering clinical regimens.
    """
    return {
        "title": "Medication Guidance",
        "warning_note": "Do not start, stop, or change any medication without consulting your doctor.",
        "points": [
            "Prescription Exclusivity: All medications, pharmaceutical tablets, and therapeutic dosages must be evaluated, prescribed, and adjusted solely by a licensed medical doctor.",
            "No Automated Prescribing: Machine learning screening models estimate statistical likelihoods and never possess clinical authorization to recommend specific pharmaceuticals or dosages.",
            "Clinical Context Required: A physician considers comprehensive diagnostic bloodwork, renal and liver function, existing prescriptions, and personal medical history before initiating pharmacotherapy.",
            "Patient Safety Protocol: If you are currently taking prescribed medications, continue taking them exactly as instructed by your healthcare provider unless your doctor explicitly advises an adjustment."
        ]
    }


def get_doctor_consultation_guidance(disease_key, is_high_risk):
    """
    Provides clear, responsible instructions regarding physician consultation.
    """
    if disease_key == "breast_cancer":
        specialist = "surgical oncologist, certified breast specialist, or gynecologist"
        crucial_note = (
            "CRITICAL MEDICAL NOTE: This machine learning screening tool evaluates morphological numerical features "
            "from digitized cell aspirate samples. It CANNOT replace clinical breast examination by a physician, "
            "bilateral digital mammography, diagnostic ultrasound, or formal histopathological biopsy confirmation."
        )
    elif disease_key == "diabetes":
        specialist = "endocrinologist, diabetologist, or primary care physician"
        crucial_note = (
            "LABORATORY CONFIRMATION NOTE: A definitive diagnosis of diabetes requires standardized laboratory venous blood tests, "
            "including Glycated Hemoglobin (HbA1c >= 6.5%), Fasting Plasma Glucose (>= 126 mg/dL), or an Oral Glucose Tolerance Test."
        )
    else:
        specialist = "cardiologist or qualified cardiovascular physician"
        crucial_note = (
            "CARDIAC SAFETY NOTE: If you or anyone experiences acute crushing chest pain, tightness radiating to the arm, neck, or jaw, "
            "unexplained shortness of breath, cold sweats, or sudden fainting, seek immediate emergency medical care (call emergency services)."
        )

    if is_high_risk:
        urgency = "Timely Clinical Evaluation Recommended"
        action_plan = [
            f"Schedule a timely clinical consultation with a {specialist} for a comprehensive physical evaluation.",
            "Bring your recent laboratory test results, vitals history, and this screening report to your clinical appointment.",
            "Discuss whether diagnostic confirmation (such as targeted blood panels, electrocardiograms, or imaging) is warranted.",
            "Maintain calm awareness: An elevated statistical screening score indicates an area for professional review, not an immediate crisis."
        ]
    else:
        urgency = "Routine Preventative Health Monitoring"
        action_plan = [
            "Continue periodic annual preventative health checkups with your primary healthcare provider.",
            "Repeat routine screening tests according to your physician's standard schedule or age-based guidelines.",
            "Consult your doctor promptly if you develop new, unexplained, or worsening clinical symptoms in the future."
        ]

    low_risk_disclaimer = (
        "Important Clinical Limitation: A low-risk result does NOT rule out disease or future health changes. "
        "Biological systems evolve, and screening estimates reflect only the specific numbers entered at this moment in time."
    )

    return {
        "urgency": urgency,
        "action_plan": action_plan,
        "crucial_note": crucial_note,
        "low_risk_disclaimer": low_risk_disclaimer
    }


def get_contributing_factors(dataset_key, features):
    """
    Extracts key out-of-range or influential clinical drivers based on physiological guidelines.
    """
    drivers = []
    if dataset_key == "heart":
        chol = float(features.get("chol", 0))
        trestbps = float(features.get("trestbps", 0))
        oldpeak = float(features.get("oldpeak", 0))
        exang = int(features.get("exang", 0))
        cp = int(features.get("cp", 0))
        ca = int(features.get("ca", 0))
        thal = int(features.get("thal", 0))

        if chol > 240:
            drivers.append(f"High Serum Cholesterol ({chol:.0f} mg/dL — clinical guideline recommends < 200 mg/dL).")
        elif chol > 200:
            drivers.append(f"Borderline Elevated Cholesterol ({chol:.0f} mg/dL — desirable range is < 200 mg/dL).")

        if trestbps >= 140:
            drivers.append(f"Stage 2 Hypertension range ({trestbps:.0f} mm Hg — normal resting BP is < 120 mm Hg).")
        elif trestbps > 120:
            drivers.append(f"Pre-hypertensive blood pressure reading ({trestbps:.0f} mm Hg).")

        if oldpeak >= 1.5:
            drivers.append(f"Significant Exercise ST Depression ({oldpeak:.1f} mm — suggests reduced coronary myocardial perfusion).")
        if exang == 1:
            drivers.append("Positive Exercise-Induced Angina (chest tightness triggered by physical exertion).")
        if cp == 4:
            drivers.append("Asymptomatic chest presentation (can be a recognized marker for silent ischemia).")
        if ca > 0:
            drivers.append(f"Fluoroscopy indicates {ca} major coronary vessel(s) with observable narrowing.")
        if thal == 7:
            drivers.append("Nuclear scan indicates reversible blood flow defect in heart muscle.")

        if not drivers:
            drivers = ["Measured cardiovascular vitals (BP, cholesterol, pulse, ECG) fall within acceptable baseline parameters."]

    elif dataset_key == "diabetes":
        glucose = float(features.get("Glucose", 0))
        bmi = float(features.get("BMI", 0))
        age = float(features.get("Age", 0))
        bp = float(features.get("BloodPressure", 0))

        if glucose >= 200:
            drivers.append(f"Significantly Elevated Glucose ({glucose:.0f} mg/dL — diabetic threshold is >= 200 mg/dL).")
        elif glucose > 140:
            drivers.append(f"Impaired Glucose Tolerance ({glucose:.0f} mg/dL — normal 2-hour reading is < 140 mg/dL).")

        if bmi >= 30:
            drivers.append(f"Elevated Body Mass Index (BMI {bmi:.1f} kg/m² — classified as obese range; risk factor for insulin resistance).")
        elif bmi >= 25:
            drivers.append(f"Overweight BMI range ({bmi:.1f} kg/m² — standard healthy reference is 18.5–24.9 kg/m²).")

        if age >= 45:
            drivers.append(f"Age Risk Factor ({age:.0f} years — risk of metabolic impairment increases after age 45).")
        if bp >= 80:
            drivers.append(f"Diastolic Blood Pressure ({bp:.0f} mm Hg — optimal resting diastolic is < 80 mm Hg).")

        if not drivers:
            drivers = ["Blood glucose, body mass index, and blood pressure markers remain within expected physiological boundaries."]

    else:  # breast cancer
        radius = float(features.get("mean_radius", 0))
        perimeter = float(features.get("mean_perimeter", 0))
        concavity = float(features.get("mean_concavity", 0))
        area = float(features.get("mean_area", 0))

        if radius >= 15.0:
            drivers.append(f"Enlarged mean cell nucleus radius ({radius:.1f} units — benign nuclei typically measure < 13.0).")
        if perimeter >= 100.0:
            drivers.append(f"Extended cell nuclear perimeter ({perimeter:.1f} units — indicates contour enlargement).")
        if concavity >= 0.12:
            drivers.append(f"Significant structural concavity ({concavity:.2f} — reflects boundary indentation typical of irregular cellular growth).")
        if area >= 700:
            drivers.append(f"Elevated nuclear cross-sectional area ({area:.0f} sq units).")

        if not drivers:
            drivers = ["Cellular contours, nuclear radius, and boundary dimensions display regular, uniform characteristics."]

    return drivers


def build_full_health_assessment(dataset_key, prob, threshold, features, chosen_model="Soft Voting Ensemble"):
    """
    Constructs the complete clinical guidance package for response payload and PDF generation.
    """
    is_high = prob >= threshold
    pct = round(prob * 100, 1)

    disease_titles = {
        "heart": "Coronary Heart Disease Risk Assessment",
        "diabetes": "Diabetes Mellitus Metabolic Risk Assessment",
        "breast_cancer": "Breast Cancer Cell Morphology Assessment"
    }
    title = disease_titles.get(dataset_key, "Smart Disease Risk Assessment")

    drivers = get_contributing_factors(dataset_key, features)
    food_recs = get_food_recommendations(dataset_key, is_high, features)
    lifestyle_recs = get_lifestyle_suggestions(dataset_key, is_high, features)
    med_guidance = get_medication_guidance(dataset_key)
    doctor_guidance = get_doctor_consultation_guidance(dataset_key, is_high)

    if is_high:
        if dataset_key == "heart":
            category = "High Cardiovascular Risk"
        elif dataset_key == "breast_cancer":
            category = "High Malignancy Indication"
        else:
            category = "Elevated Metabolic Risk"
        badge = "danger" if dataset_key != "diabetes" else "warning"
        headline = f"Assessment indicates {pct}% estimated likelihood of {dataset_key.replace('_', ' ')}."
    else:
        if dataset_key == "heart":
            category = "Low Cardiovascular Risk"
        elif dataset_key == "breast_cancer":
            category = "Low Malignancy Indication (Benign Pattern)"
        else:
            category = "Favorable Metabolic Profile"
        badge = "success"
        headline = f"Favorable screening profile with {pct}% estimated disease risk."

    return {
        "disease_key": dataset_key,
        "disease_title": title,
        "probability": round(prob, 4),
        "probability_pct": pct,
        "threshold": threshold,
        "is_high_risk": is_high,
        "category": category,
        "badge": badge,
        "headline": headline,
        "contributing_factors": drivers,
        "food_recommendations": food_recs,
        "lifestyle_suggestions": lifestyle_recs,
        "medication_guidance": med_guidance,
        "doctor_consultation": doctor_guidance,
        "chosen_model": chosen_model
    }
