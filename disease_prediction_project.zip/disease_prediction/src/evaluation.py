"""
Clinical Evaluation Suite
Adheres directly to Slide 11:
- Computes Sensitivity, Specificity, ROC-AUC, PR-AUC, F1, Balanced Accuracy, Brier Score.
- Runs 5-Fold Stratified Cross-Validation on identical folds.
- Computes calibration curves, ROC curves, and PR curves.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    confusion_matrix, roc_auc_score, average_precision_score,
    f1_score, balanced_accuracy_score, brier_score_loss,
    roc_curve, precision_recall_curve
)
from sklearn.calibration import calibration_curve


def compute_clinical_metrics(y_true, y_prob, threshold=0.5):
    """
    Computes patient-centric diagnostic metrics at a specified decision threshold.
    """
    y_pred = (y_prob >= threshold).astype(int)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()

    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0.0  # Recall
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0  # True Negative Rate
    acc = (tp + tn) / len(y_true)
    bal_acc = balanced_accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    
    try:
        roc_auc = roc_auc_score(y_true, y_prob)
    except Exception:
        roc_auc = 0.5
        
    try:
        pr_auc = average_precision_score(y_true, y_prob)
    except Exception:
        pr_auc = 0.0

    brier = brier_score_loss(y_true, y_prob)

    return {
        "Sensitivity (Recall)": sensitivity,
        "Specificity": specificity,
        "Accuracy": acc,
        "Balanced Accuracy": bal_acc,
        "F1-Score": f1,
        "ROC-AUC": roc_auc,
        "PR-AUC": pr_auc,
        "Brier Score": brier,
        "TP": int(tp), "FP": int(fp), "TN": int(tn), "FN": int(fn)
    }


def evaluate_cv(models_dict, X, y, n_splits=5, random_state=42):
    """
    Conducts stratified k-fold cross-validation across all candidate and ensemble models.
    Returns:
    - summary_df: Mean ± Std for each metric across folds.
    - detailed_oof: Out-of-fold probability predictions for curve generation.
    """
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    
    cv_records = []
    oof_predictions = {name: np.zeros(len(y)) for name in models_dict}

    for fold, (train_idx, val_idx) in enumerate(skf.split(X, y), 1):
        X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
        y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

        for name, model in models_dict.items():
            # Clone/fit model strictly on train split
            model.fit(X_train, y_train)
            
            if hasattr(model, "predict_proba"):
                y_prob = model.predict_proba(X_val)[:, 1]
            else:
                decision = model.decision_function(X_val)
                y_prob = 1 / (1 + np.exp(-decision))

            oof_predictions[name][val_idx] = y_prob
            metrics = compute_clinical_metrics(y_val, y_prob, threshold=0.5)
            metrics["Model"] = name
            metrics["Fold"] = fold
            cv_records.append(metrics)

    df_records = pd.DataFrame(cv_records)

    # Compute aggregation
    summary = df_records.groupby("Model").agg({
        "Sensitivity (Recall)": ["mean", "std"],
        "Specificity": ["mean", "std"],
        "Accuracy": ["mean", "std"],
        "Balanced Accuracy": ["mean", "std"],
        "F1-Score": ["mean", "std"],
        "ROC-AUC": ["mean", "std"],
        "PR-AUC": ["mean", "std"],
        "Brier Score": ["mean", "std"]
    })

    return summary, df_records, oof_predictions


# ---------------------------------------------------------------------
# Publication & Presentation Quality Visualization Plotters
# ---------------------------------------------------------------------
COLORS = {
    "Logistic Regression": "#4285F4",
    "Decision Tree": "#FBBC05",
    "Random Forest": "#34A853",
    "Gradient Boosting": "#EA4335",
    "Support Vector Machine": "#9C27B0",
    "Soft Voting Ensemble": "#00ACC1",
    "Stacking Ensemble": "#FF6D00"
}


def plot_roc_curves(oof_preds, y_true, dataset_name, save_path):
    """
    Plots comparative ROC curves for all standalone and ensemble models.
    """
    plt.figure(figsize=(9, 7), dpi=300)
    plt.plot([0, 1], [0, 1], "k--", alpha=0.6, label="Random Chance (AUC = 0.500)")

    for name, y_prob in oof_preds.items():
        fpr, tpr, _ = roc_curve(y_true, y_prob)
        auc = roc_auc_score(y_true, y_prob)
        color = COLORS.get(name, None)
        lw = 2.5 if "Ensemble" in name else 1.5
        plt.plot(fpr, tpr, label=f"{name} (AUC = {auc:.3f})", color=color, linewidth=lw)

    plt.xlabel("False Positive Rate (1 - Specificity)", fontsize=12, fontweight="bold")
    plt.ylabel("True Positive Rate (Sensitivity)", fontsize=12, fontweight="bold")
    plt.title(f"ROC Curve Comparison · {dataset_name}", fontsize=14, fontweight="bold", pad=12)
    plt.legend(loc="lower right", frameon=True, fontsize=10)
    plt.grid(True, linestyle=":", alpha=0.6)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()


def plot_pr_curves(oof_preds, y_true, dataset_name, save_path):
    """
    Plots Precision-Recall curves.
    """
    plt.figure(figsize=(9, 7), dpi=300)
    baseline_pr = y_true.mean()
    plt.axhline(baseline_pr, color="k", linestyle="--", alpha=0.6, label=f"Baseline Rate ({baseline_pr:.2f})")

    for name, y_prob in oof_preds.items():
        precision, recall, _ = precision_recall_curve(y_true, y_prob)
        ap = average_precision_score(y_true, y_prob)
        color = COLORS.get(name, None)
        lw = 2.5 if "Ensemble" in name else 1.5
        plt.plot(recall, precision, label=f"{name} (PR-AUC = {ap:.3f})", color=color, linewidth=lw)

    plt.xlabel("Recall (Sensitivity)", fontsize=12, fontweight="bold")
    plt.ylabel("Precision (Positive Predictive Value)", fontsize=12, fontweight="bold")
    plt.title(f"Precision-Recall Curve Comparison · {dataset_name}", fontsize=14, fontweight="bold", pad=12)
    plt.legend(loc="lower left", frameon=True, fontsize=10)
    plt.grid(True, linestyle=":", alpha=0.6)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()


def plot_calibration_curves(oof_preds, y_true, dataset_name, save_path):
    """
    Plots reliability calibration diagram (Slide 11: Calibration / Brier).
    """
    plt.figure(figsize=(9, 7), dpi=300)
    plt.plot([0, 1], [0, 1], "k--", label="Perfect Calibration", alpha=0.7)

    for name, y_prob in oof_preds.items():
        prob_true, prob_pred = calibration_curve(y_true, y_prob, n_bins=8, strategy="uniform")
        brier = brier_score_loss(y_true, y_prob)
        color = COLORS.get(name, None)
        lw = 2.5 if "Ensemble" in name else 1.5
        plt.plot(prob_pred, prob_true, "s-", label=f"{name} (Brier = {brier:.3f})", color=color, linewidth=lw)

    plt.xlabel("Mean Predicted Probability", fontsize=12, fontweight="bold")
    plt.ylabel("Fraction of Observed Positives", fontsize=12, fontweight="bold")
    plt.title(f"Probability Calibration Curves · {dataset_name}", fontsize=14, fontweight="bold", pad=12)
    plt.legend(loc="upper left", frameon=True, fontsize=10)
    plt.grid(True, linestyle=":", alpha=0.6)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()


def plot_metrics_comparison_bar(df_records, dataset_name, save_path):
    """
    Bar chart comparing Sensitivity, Specificity, F1, and ROC-AUC.
    """
    plt.figure(figsize=(12, 6), dpi=300)
    melted = df_records.melt(
        id_vars=["Model"],
        value_vars=["Sensitivity (Recall)", "Specificity", "F1-Score", "ROC-AUC"],
        var_name="Metric",
        value_name="Score"
    )
    ax = sns.barplot(data=melted, x="Model", y="Score", hue="Metric", palette="tab10", errorbar="sd")
    plt.xticks(rotation=25, ha="right", fontsize=10, fontweight="bold")
    plt.ylabel("Cross-Validated Metric Score", fontsize=12, fontweight="bold")
    plt.ylim(0.4, 1.05)
    plt.title(f"Clinical Performance Comparison · {dataset_name}", fontsize=14, fontweight="bold", pad=12)
    plt.legend(loc="lower right", frameon=True)
    plt.grid(axis="y", linestyle=":", alpha=0.6)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
