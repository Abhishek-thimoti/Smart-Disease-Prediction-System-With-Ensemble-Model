"""
Smart Disease Prediction System with Model Ensemble
Aligns with Project Review - I presentation specifications.
"""
__version__ = "1.0.0"
